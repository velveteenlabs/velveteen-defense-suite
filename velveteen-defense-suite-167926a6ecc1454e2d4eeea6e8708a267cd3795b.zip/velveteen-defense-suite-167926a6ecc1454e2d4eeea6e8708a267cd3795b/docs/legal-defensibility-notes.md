﻿# Legal Defensibility Notes

