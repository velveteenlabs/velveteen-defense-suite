﻿# Quick triage runner

