﻿# Artifact Finalization Guide

